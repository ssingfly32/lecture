package com.ksh.service.member;

import com.ksh.vodto.Member;
import com.ksh.vodto.MemberDTO;

public interface MemberService {
	
	// 로그인 
	Member login(MemberDTO tmpMember) throws Exception;
}

package com.ksh.service.member;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ksh.persistence.MemberDAO;
import com.ksh.persistence.PointLogDAO;
import com.ksh.vodto.Member;
import com.ksh.vodto.MemberDTO;
import com.ksh.vodto.PointLog;
import com.ksh.vodto.SessionDTO;

@Service
public class MemberServiceImpl implements MemberService {

	@Inject
	private MemberDAO mdao;

	@Inject
	private PointLogDAO pdao;

	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	Timestamp curDate = new Timestamp(System.currentTimeMillis());

	@Override
	@Transactional(rollbackFor = Exception.class)
	public Member login(MemberDTO tmpMember) throws Exception {
		// 1) 로그인 해본다
		Member loginMember = mdao.login(tmpMember);
		System.out.println(loginMember.toString());
		// 2) 로그인이 성공하면 member 테이블에 userpoint update (하루 한번 로그인 포인트 주는거 혼자 해보기)
		if (loginMember != null) {
			if (mdao.DailyLoginPoint(loginMember.getUserId(), "로그인") != null) { // 로그인 포인트 이력이 있을 때
				PointLog pl = mdao.DailyLoginPoint(loginMember.getUserId(), "로그인");
				if (!sdf.format(pl.getWhen()).equals(sdf.format(curDate))) {
					if (mdao.updateUserPoint("로그인", loginMember.getUserId()) == 1) {
						// 3) 2번 이후에 pointlog 테이블에 insert
						pdao.insertPointLog("로그인", loginMember.getUserId());	// mapper selectKey 활용 완료
					}
				}
			} else {	// 로그인 포인트 이력이 없을 때
				if (mdao.updateUserPoint("로그인", loginMember.getUserId()) == 1) { // 최초 로그인
					pdao.insertPointLog("로그인", loginMember.getUserId());	
				}
			}
		}

		return loginMember;
	}

	@Override
	public boolean remember(SessionDTO sesDto) throws Exception {
		boolean result = false;
		
		if(mdao.insertSession(sesDto) == 1) {
			result = true;
		}
		return result;
	}

	@Override
	public Member checkAutoLoginUser(String sessionKey) throws Exception {
		
		return mdao.selectAutoLoginUser(sessionKey);
	}

}

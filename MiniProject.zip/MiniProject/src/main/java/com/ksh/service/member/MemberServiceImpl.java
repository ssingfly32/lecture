package com.ksh.service.member;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ksh.persistence.MemberDAO;
import com.ksh.persistence.PointLogDAO;
import com.ksh.vodto.Member;
import com.ksh.vodto.MemberDTO;
import com.ksh.vodto.PointLog;

@Service
public class MemberServiceImpl implements MemberService {

	@Inject
	private MemberDAO mdao;
	
	@Inject
	private PointLogDAO pdao;
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public Member login(MemberDTO tmpMember) throws Exception {
		// 1) 로그인 해본다
		Member loginMember = mdao.login(tmpMember);
		System.out.println(loginMember.toString());
		// 2) 로그인이 성공하면 member 테이블에 userpoint update (하루 한번 로그인 포인트 주는거 혼자 해보기)
		if (loginMember != null) {
			if(mdao.updateUserPoint("로그인", loginMember.getUserId()) == 1) {
				// 3) 2번 이후에 pointlog 테이블에 insert
				pdao.insertPointLog(new PointLog(-1, null, "로그인", 5, loginMember.getUserId()));
				
			}
		}
		
		
		
		return loginMember;
	}

}

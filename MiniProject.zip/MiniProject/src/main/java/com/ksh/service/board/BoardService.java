package com.ksh.service.board;

import java.util.List;
import java.util.Map;

import com.ksh.vodto.Board;
import com.ksh.vodto.UploadedFile;

public interface BoardService {
	// 게시글 전체 조회
	Map<String, Object> getEntireBoard(int pageNo) throws Exception;

	// 게시글 저장
	void saveNewBoard(Board newBoard, List<UploadedFile> lst) throws Exception;

	// 게시글 상세조회
	Map<String, Object> getBoardByNo(int no, String ipAddr) throws Exception;

	// 글 번호로 글 작성자 얻어오기
	String getBoardWriterByNo(int no) throws Exception;

	// 좋아요
	boolean likeBoard(int boardNo, String who) throws Exception;

	// 안좋아요
	boolean dislikeBoard(int boardNo, String who) throws Exception;

	// 좋아요를 누른 사람들
	List<String> selectPeopleWhoLikesBoard(int boardNo) throws Exception;
	
	// 좋아요 수 증감
	int updateBoardCount(int n, int boardNo) throws Exception;
}

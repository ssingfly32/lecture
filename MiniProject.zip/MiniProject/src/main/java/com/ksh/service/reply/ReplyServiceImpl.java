package com.ksh.service.reply;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.ksh.persistence.MemberDAO;
import com.ksh.persistence.PointLogDAO;
import com.ksh.persistence.ReplyDAO;
import com.ksh.vodto.PointLog;
import com.ksh.vodto.Reply;

@Service
public class ReplyServiceImpl implements ReplyService {

	@Inject
	private ReplyDAO rDao;
	
	@Inject
	private MemberDAO mDao;
	
	@Inject
	private PointLogDAO pDao;
	
	@Override
	public List<Reply> getAllReplies(int boardNo) throws Exception {
		
		List<Reply> lst = rDao.selectAllReplies(boardNo);
		return lst;
	}

	@Override
	@Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
	public boolean saveReply(Reply reply) throws Exception {
		boolean result = false;
		// 1) 댓글 저장
		if(rDao.insertNewReply(reply) == 1) {
			// 2) member테이블 userPoint update
			if (mDao.updateUserPoint("답글작성", reply.getReplyer()) == 1) {
				// 3) pointLog 테이블 insert
				if(pDao.insertPointLog("답글작성", reply.getReplyer()) == 1) {
					result = true;
				}
			}
		}
		return result;
	}

}

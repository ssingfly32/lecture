package com.ksh.service.board;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.ksh.etc.PagingInfo;
import com.ksh.persistence.BoardDAO;
import com.ksh.persistence.MemberDAO;
import com.ksh.persistence.PointLogDAO;
import com.ksh.vodto.Board;
import com.ksh.vodto.PointLog;
import com.ksh.vodto.ReadCountProcess;
import com.ksh.vodto.UploadedFile;

@Service // 아래의 객체가 Service 객체임을 명시
public class BoardServiceImpl implements BoardService {

	@Inject
	private BoardDAO bDao;

	@Inject
	private MemberDAO mDao;

	@Inject
	private PointLogDAO plDao;

	@Override
	public Map<String, Object> getEntireBoard(int pageNo) throws Exception {
		PagingInfo pi = makePagingInfo(pageNo);
		
		List<Board> lst = bDao.selectAllBoard(pi);

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("boardList", lst);
		result.put("pagingInfo", pi);
		return result;
	}

	/**
	 * @MethodName : makePagingInfo
	 * @author : ksh
	 * @return
	 * @throws Exception 
	 * @returnValue : 
	 * @description : 페이징 처리를 위한 PagingInfo 객체 만들어서 반환
	 * @date : 2023. 9. 15.
	 */
	private PagingInfo makePagingInfo(int pageNo) throws Exception {
		PagingInfo result = new PagingInfo();
		
		// 현재 페이지 번호 세팅
		result.setPageNo(pageNo);
		// 전체 글의 갯수
		result.setTotalPostCnt(bDao.getTotalPostCnt());
		
		// 총 페이지 수 구하기
		result.setTotalPageCnt(result.getTotalPostCnt(), result.getViewPostCntPerPage());
		
		// 보여주기 시작할 row index 번호 구하기
		result.setStartRowIndex();
		
		// --------------------------------------------------
		// 몇 개의 페이징 블럭이 나오는지...
		result.setTotalPagingBlockCnt();
		
		// 현재 페이지가 속한 페이징 블럭 번호
		result.setPageBlockOfCurrentPage();
		
		// 현재 블럭의 시작 페이지 번호 구하기
		result.setStartNumOfCurrentPagingBlock();
		
		// 현재 블럭의 끝 페이지 번호 구하기
		result.setEndNumOfCurrentPagingBlock();
		
		return result;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void saveNewBoard(Board newBoard, List<UploadedFile> lst) throws Exception {
		// 게시글 본문 줄바꿈 처리
		newBoard.setContent(newBoard.getContent().replace("\r\n", "<br />"));

//		1) 게시글을 DB에 insert
		if (bDao.insertNewBoard(newBoard) == 1) {
			int boardNo = bDao.selectRecentlyBoardNo();

//		업로드 파일이 있는 경우
//		업로드 파일의 갯수만큼 반복처리
//		2) 1번에서 insert된 no를 얻어와(boardNo컬럼에) uploadedFile 테이블에 파일 정보를 insert
//
			if (lst.size() > 0) { // 업로드 한 파일이 있다
				for (UploadedFile uf : lst) {
					bDao.insertUploadedFile(boardNo, uf);
				}
			}

//		3) 멤버 테이블에 userpoint update
			mDao.updateUserPoint("게시물작성", newBoard.getWriter());
//		4) pointlog 테이블에 insert
			plDao.insertPointLog("게시물작성", newBoard.getWriter());

		}

	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public Map<String, Object> getBoardByNo(int no, String ipAddr) throws Exception {
		Map<String, Object> result = new HashMap<String, Object>();
		
		int readCntResult = -1;
		// 비즈니스 로직이 뭐가 있는지 먼저 생각해보자
		if (bDao.selectReadCountProcess(no, ipAddr) != null) { // 조회한 적이 있다.
			// 해당 아이피주소와 글번호 같은 것이 있다면...
			if (bDao.getHourDiffReadTime(no, ipAddr) > 23) { // 시간이 24시간이 지난 경우
//				-> 아이피 주소와 글번호 읽은 시간을 readcountprocess 테이블에 update
				if (bDao.updateReadCountProcess(new ReadCountProcess(-1, ipAddr, no, null)) == 1) {
//				-> 해당 글번호의 readcount를 증가 (update)
					readCntResult = bDao.updateReadCount(no);

				}

			} else {
				readCntResult = 1;
			}
		} else { // 해당 ipAddr이 no 번 글을 최초 조회
//			-> 아이피 주소와 글번호 읽은 시간을 readcountprocess 테이블에 insert
			if (bDao.insertReadCountProcess(new ReadCountProcess(-1, ipAddr, no, null)) == 1) {
//			-> 해당 글번호의 readcount를 증가
				readCntResult = bDao.updateReadCount(no);
			}
		}
		
		if (readCntResult == 1) {
			// no번의 글 가져오자
			Board board = bDao.selectBoardByNo(no);
			// uploadedFile도 가져오기
			List<UploadedFile> upFileLst = bDao.selectUploadedFile(no);
			// 이 글을 좋아하는 분들을 가져오기
			List<String> likePeople = selectPeopleWhoLikesBoard(no);
			
			result.put("board", board);
			result.put("upFileLst", upFileLst);
			result.put("likePeople", likePeople);
		}
		
		return result;
	}

	@Override
	public String getBoardWriterByNo(int no) throws Exception {
		
		return bDao.getWriterByNo(no);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean likeBoard(int boardNo, String who) throws Exception {
		boolean result = false;
		if(bDao.likeBoard(boardNo, who)==1) {
			if(this.updateBoardCount(1, boardNo) == 1) {
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean dislikeBoard(int boardNo, String who) throws Exception {
		boolean result = false;
		if(bDao.dislikeBoard(boardNo, who)==1) {
			if(this.updateBoardCount(-1, boardNo) == 1) {
				result = true;
			}
		}
		return result;
	}

	@Override
	public List<String> selectPeopleWhoLikesBoard(int boardNo) throws Exception {
		 
		return bDao.selectPeopleWhoLikesBoard(boardNo);
	}

	@Override
	public int updateBoardCount(int n, int boardNo) throws Exception {
		return bDao.updateBoardCount(n, boardNo);
	}

}

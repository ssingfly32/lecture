package com.ksh.service.board;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ksh.persistence.BoardDAO;
import com.ksh.persistence.MemberDAO;
import com.ksh.persistence.PointLogDAO;
import com.ksh.vodto.Board;
import com.ksh.vodto.PointLog;
import com.ksh.vodto.UploadedFile;

@Service // 아래의 객체가 Service 객체임을 명시
public class BoardServiceImpl implements BoardService {

	@Inject
	private BoardDAO bDao;

	@Inject
	private MemberDAO mDao;

	@Inject
	private PointLogDAO plDao;

	@Override
	public List<Board> getEntireBoard() throws Exception {
		List<Board> lst = bDao.selectAllBoard();

		return lst;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void saveNewBoard(Board newBoard, List<UploadedFile> lst) throws Exception {
		// 게시글 본문 줄바꿈 처리
		newBoard.setContent(newBoard.getContent().replace("\r\n", "<br />"));

//		1) 게시글을 DB에 insert
		if (bDao.insertNewBoard(newBoard) == 1) {
			int boardNo = bDao.selectRecentlyBoardNo();


//		업로드 파일이 있는 경우
//		업로드 파일의 갯수만큼 반복처리
//		2) 1번에서 insert된 no를 얻어와(boardNo컬럼에) uploadedFile 테이블에 파일 정보를 insert
//
			if (lst.size() > 0) { // 업로드 한 파일이 있다
				for (UploadedFile uf : lst) {
					bDao.insertUploadedFile(boardNo, uf);
				}
			}

//		3) 멤버 테이블에 userpoint update
			mDao.updateUserPoint(2, newBoard.getWriter());
//		4) pointlog 테이블에 insert
			plDao.insertPointLog(new PointLog(-1, null, "게시물작성", 2, newBoard.getWriter()));

		}

	}

}

package com.ksh.service.board;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.ksh.persistence.BoardDAO;
import com.ksh.persistence.MemberDAO;
import com.ksh.persistence.PointLogDAO;
import com.ksh.vodto.Board;
import com.ksh.vodto.PointLog;
import com.ksh.vodto.ReadCountProcess;
import com.ksh.vodto.UploadedFile;

@Service // 아래의 객체가 Service 객체임을 명시
public class BoardServiceImpl implements BoardService {

	@Inject
	private BoardDAO bDao;

	@Inject
	private MemberDAO mDao;

	@Inject
	private PointLogDAO plDao;

	@Override
	public List<Board> getEntireBoard() throws Exception {
		List<Board> lst = bDao.selectAllBoard();

		return lst;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void saveNewBoard(Board newBoard, List<UploadedFile> lst) throws Exception {
		// 게시글 본문 줄바꿈 처리
		newBoard.setContent(newBoard.getContent().replace("\r\n", "<br />"));

//		1) 게시글을 DB에 insert
		if (bDao.insertNewBoard(newBoard) == 1) {
			int boardNo = bDao.selectRecentlyBoardNo();

//		업로드 파일이 있는 경우
//		업로드 파일의 갯수만큼 반복처리
//		2) 1번에서 insert된 no를 얻어와(boardNo컬럼에) uploadedFile 테이블에 파일 정보를 insert
//
			if (lst.size() > 0) { // 업로드 한 파일이 있다
				for (UploadedFile uf : lst) {
					bDao.insertUploadedFile(boardNo, uf);
				}
			}

//		3) 멤버 테이블에 userpoint update
			mDao.updateUserPoint(2, newBoard.getWriter());
//		4) pointlog 테이블에 insert
			plDao.insertPointLog(new PointLog(-1, null, "게시물작성", 2, newBoard.getWriter()));

		}

	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = Exception.class)
	public Map<String, Object> getBoardByNo(int no, String ipAddr) throws Exception {
		Map<String, Object> result = new HashMap<String, Object>();
		
		int readCntResult = -1;
		// 비즈니스 로직이 뭐가 있는지 먼저 생각해보자
		if (bDao.selectReadCountProcess(no, ipAddr) != null) { // 조회한 적이 있다.
			// 해당 아이피주소와 글번호 같은 것이 있다면...
			if (bDao.getHourDiffReadTime(no, ipAddr) > 23) { // 시간이 24시간이 지난 경우
//				-> 아이피 주소와 글번호 읽은 시간을 readcountprocess 테이블에 update
				if (bDao.updateReadCountProcess(new ReadCountProcess(-1, ipAddr, no, null)) == 1) {
//				-> 해당 글번호의 readcount를 증가 (update)
					readCntResult = bDao.updateReadCount(no);

				}

			} else {
				readCntResult = 1;
			}
		} else { // 해당 ipAddr이 no 번 글을 최초 조회
//			-> 아이피 주소와 글번호 읽은 시간을 readcountprocess 테이블에 insert
			if (bDao.insertReadCountProcess(new ReadCountProcess(-1, ipAddr, no, null)) == 1) {
//			-> 해당 글번호의 readcount를 증가
				readCntResult = bDao.updateReadCount(no);
			}
		}
		
		if (readCntResult == 1) {
			// no번의 글 가져오자
			Board board = bDao.selectBoardByNo(no);
			// uploadedFile도 가져오기
			List<UploadedFile> upFileLst = bDao.selectUploadedFile(no);
			
			result.put("board", board);
			result.put("upFileLst", upFileLst);
		}
		
		return result;
	}

}

package com.ksh.interceptor;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ksh.etc.DestinationPath;
import com.ksh.service.board.BoardService;
import com.ksh.vodto.Member;

public class AuthentificationInterceptor extends HandlerInterceptorAdapter {

	@Inject // 스프링 컨테이너 객체에 접근 가능
	private BoardService service;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		boolean result = false;

		System.out.println("AuthentificationInterceptor - preHandle()");

	
		String requestUri = request.getRequestURI();
		
		HttpSession ses = request.getSession();
		// 로그인 했는지 안했는지 확인
		if ((Member) ses.getAttribute("loginMember") != null) {
			// 로그인 했다면 (하던 것 계속 하게 하기)
			
			if(requestUri.contains("modifyBoard") || requestUri.contains("remBoard")) {
				// 만약 게시판 글수정 / 글삭제 페이지에서 온거라면....
				// 로그인 한 유저가 글 수정 삭제 권한이 있는 유저인지 판별
				String loginUser = ((Member) ses.getAttribute("loginMember")).getUserId();
				int no = Integer.parseInt(request.getParameter("no"));
				if (!service.getBoardWriterByNo(no).equals(loginUser)) {
					// 글 작성자와 로그인 유저가 같지 않다 - > 수정 삭제 불가
					response.sendRedirect("viewBoard?status=notPermission&no=" + no);
					return false;
				}
			}
			
			
			result = true;
		} else if ((Member) ses.getAttribute("loginMember") == null) {
			// 로그인 하지 않았다면 로그인 하러 가기

			DestinationPath.savePrePath(request);

			response.sendRedirect("/member/login");
			return false;
			// 로그인을 하면 (하던 것 계속 하게 하기)

		}

		return result;
	}

}

package com.ksh.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ksh.vodto.Member;

public class LoginInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		System.out.println("LoginInterceptor - preHandle()");
		// 댓글 작성은 아작스여서 인터셉터에 안걸림
		if (request.getMethod().equals("GET")) {	// GET방식으로 요청했을때만 동작
			// 쿼리스트링에 redirectUrl 값이 존재한다면 

			if (!request.getParameter("redirectUrl").equals("") || request.getParameter("redirectUrl") != null) {
				// 그리고 그 값에 viewBoard가 포함되어 있다면
				if (request.getParameter("redirectUrl").contains("viewBoard")) {
					// 댓글 달려다가 로그인 하러 끌려옴
					String uri = "/board/viewBoard";
					String queryStr = "?no=" + request.getParameter("no");
					
					// 로그인하고 달려던 글 번호로 다시 가도록 남겨놓음
					request.getSession().setAttribute("returnPath", uri + queryStr);
				}
			}
		}
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		System.out.println("LoginInterceptor - postHandle()");

		HttpSession ses = request.getSession();

		ModelMap modelMap = modelAndView.getModelMap();
		Member loginMember = (Member) modelMap.get("loginMember");

		// 로그인을 성공했다면 session에 로그인 기록을 남겨야 함
		if (loginMember != null) {
			ses.setAttribute("loginMember", loginMember); // 로그인 기록 세션에 남기기
			System.out.println(loginMember.toString());

			// 만약 게시판 글수정 / 글삭제 페이지에서 온거라면....
			// 로그인 한 유저가 글 수정 삭제 권한이 있는 유저인지 판별

			String returnPath = "";
			if (ses.getAttribute("returnPath") != null) {

				returnPath = (String) ses.getAttribute("returnPath");

			}

			// 로그인 하지 않은 상태로 게시판(글작성/수정/삭제)에 접근 했을 경우에 이전 경로로 가고
			// 이전 경로가 없을 때 로그인 했다면 /로
			response.sendRedirect(!returnPath.equals("") ? returnPath : "/");
		}
	}

}

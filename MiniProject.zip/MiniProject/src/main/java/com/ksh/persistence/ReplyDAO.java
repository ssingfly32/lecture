package com.ksh.persistence;

import java.util.List;

import com.ksh.vodto.Reply;

public interface ReplyDAO {
	// 모든 댓글 긁어오기
	List<Reply> selectAllReplies(int boardNo) throws Exception;
}

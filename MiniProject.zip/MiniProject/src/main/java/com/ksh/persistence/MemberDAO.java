package com.ksh.persistence;

import java.util.List;

import com.ksh.vodto.Member;
import com.ksh.vodto.MemberDTO;
import com.ksh.vodto.PointLog;
import com.ksh.vodto.SessionDTO;



public interface MemberDAO {
	// 현재날짜와 현재 시간을 얻어오는 
	public String getDate();
	
	// member 테이블에 포인트 증감
	public int updateUserPoint(String why, String userId) throws Exception;
	
	// 로그인
	Member login(MemberDTO tmpLogin) throws Exception;

	// 데일리 로그인 포인트
	public PointLog DailyLoginPoint(String userId, String why) throws Exception;
	
	// 자동 로그인을 위한 세션키, 세션 만료일 저장
	int insertSession(SessionDTO sesDTO) throws Exception;

	// 자동 로그인 유저 체크
	public Member selectAutoLoginUser(String sessionKey);
	
}

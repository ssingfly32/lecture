package com.ksh.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.ksh.vodto.Member;
import com.ksh.vodto.MemberDTO;
import com.ksh.vodto.PointLog;
import com.ksh.vodto.SessionDTO;



@Repository	// 아래의 클래스가 DAO객체임을 명시 
public class MemberDAOImpl implements MemberDAO {

	@Inject
	private SqlSession ses;	// SqlSessionTemplate 객체 주입

	private static String ns = "com.ksh.mappers.MemberMapper";
	
	@Override
	public String getDate() {
		// Connection
		
		String q = ns + ".curDate";
		
		return ses.selectOne(q);
	}

	@Override
	public int updateUserPoint(String why, String userId) throws Exception {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("why", why);
		param.put("userId", userId);
		
		return ses.update(ns + ".updateUserPoint", param);
	}

	@Override
	public Member login(MemberDTO tmpLogin) throws Exception {
		
		return ses.selectOne(ns + ".login", tmpLogin);
	}

	@Override
	public PointLog DailyLoginPoint(String userId, String why) throws Exception {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("who", userId);
		param.put("why", why);
		return ses.selectOne(ns+".DailyLoginPoint", param);
	}

	@Override
	public int insertSession(SessionDTO sesDTO) throws Exception {
		
		return ses.update(ns + ".insertSessionKey", sesDTO);
	}

	@Override
	public Member selectAutoLoginUser(String sessionKey) {
		return ses.selectOne(ns+".selectAutoLoginUser", sessionKey);
	}

	
	

}

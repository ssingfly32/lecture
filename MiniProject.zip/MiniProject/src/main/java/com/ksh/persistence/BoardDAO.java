package com.ksh.persistence;

import java.util.List;

import com.ksh.etc.PagingInfo;
import com.ksh.vodto.Board;
import com.ksh.vodto.ReadCountProcess;
import com.ksh.vodto.UploadedFile;

public interface BoardDAO {
	List<Board> selectAllBoard(PagingInfo pi) throws Exception;
	
	int insertNewBoard(Board newBoard) throws Exception;

	int selectRecentlyBoardNo() throws Exception;

	void insertUploadedFile(int boardNo, UploadedFile uf) throws Exception;

	ReadCountProcess selectReadCountProcess(int no, String ipAddr) throws Exception;
	
	int getHourDiffReadTime(int no, String ipAddr) throws Exception; 
	
	int updateReadCountProcess(ReadCountProcess rcp) throws Exception; 
	
	int updateReadCount(int no) throws Exception;
	
	int insertReadCountProcess(ReadCountProcess rcp) throws Exception;
	
	// no번 게시글 찾기
	Board selectBoardByNo(int no) throws Exception;
	
	// no번 글의 첨부 파일 가져오기
	List<UploadedFile> selectUploadedFile(int no) throws Exception;
	
	// no번 글의 작성자 얻어오기
	String getWriterByNo(int no) throws Exception;
	
	// 좋아요
	int likeBoard(int boardNo, String who) throws Exception;
	
	// 안좋아요
	int dislikeBoard(int boardNo, String who) throws Exception;
	
	// 좋아요를 누른 사람들
	List<String> selectPeopleWhoLikesBoard(int boardNo) throws Exception;
	
	// 좋아요 수 증감
	int updateBoardCount(int n, int boardNo) throws Exception;

	// Board 테이블의 전체 글의 갯수
	int getTotalPostCnt() throws Exception;
	
}

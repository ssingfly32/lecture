package com.ksh.persistence;

import java.util.List;

import com.ksh.vodto.Board;

public interface BoardDAO {
	List<Board> selectAllBoard();
}

package com.ksh.persistence;

import java.util.List;

import com.ksh.vodto.Board;
import com.ksh.vodto.UploadedFile;

public interface BoardDAO {
	List<Board> selectAllBoard() throws Exception;
	
	int insertNewBoard(Board newBoard) throws Exception;

	int selectRecentlyBoardNo() throws Exception;

	void insertUploadedFile(int boardNo, UploadedFile uf) throws Exception;
	
}

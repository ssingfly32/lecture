package com.ksh.persistence;

import com.ksh.vodto.PointLog;

public interface PointLogDAO {
	int insertPointLog(PointLog pl) throws Exception;
}

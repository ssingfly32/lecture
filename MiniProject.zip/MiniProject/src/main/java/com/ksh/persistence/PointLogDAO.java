package com.ksh.persistence;

import com.ksh.vodto.PointLog;

public interface PointLogDAO {
	
	//pointlog 테이블에 insert
	int insertPointLog(String why, String userId) throws Exception;
}

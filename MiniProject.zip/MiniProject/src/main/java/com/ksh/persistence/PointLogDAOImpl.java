package com.ksh.persistence;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.ksh.vodto.PointLog;

@Repository
public class PointLogDAOImpl implements PointLogDAO {

	@Inject
	private SqlSession ses;
	
	private static String ns = "com.ksh.mappers.PointLogMapper";
	
	@Override
	public int insertPointLog(String why, String userId) throws Exception {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("who", userId);
		param.put("why", why);
		return ses.insert(ns + ".insertPointLog", param);
	}

}

package com.ksh.persistence;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.ksh.vodto.PointLog;

@Repository
public class PointLogDAOImpl implements PointLogDAO {

	@Inject
	private SqlSession ses;
	
	private static String ns = "com.ksh.mappers.PointLogMapper";
	
	@Override
	public int insertPointLog(PointLog pl) throws Exception {
		
		return ses.insert(ns + ".insertPointLog", pl);
	}

}

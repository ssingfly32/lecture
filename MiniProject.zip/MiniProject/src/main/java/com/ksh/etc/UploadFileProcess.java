package com.ksh.etc;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.imgscalr.Scalr;
import org.imgscalr.Scalr.Mode;
import org.springframework.util.FileCopyUtils;

import com.ksh.vodto.UploadedFile;

/**
 * @packageName : com.ksh.etc
 * @fileName :  UploadFileProcess.java
 * @author : ksh
 * @date : 2023. 9. 1.
 * @description : 업로드된 파일을 처리한다
 */
public class UploadFileProcess {

	/**
	 * @MethodName : fileUpload
	 * @author : ksh
	 * @param originalFilename
	 * @param size
	 * @param contentType
	 * @param bytes
	 * @param realPath
	 * @return 
	 * @returnValue : 
	 * @description : 파일 업로드 처리의 전체 컨트롤
	 * @date : 2023. 9. 1.
	 */
	
	// 정적메소드 : 말 그대로 정적이기 때문에, 클래스가 메모리에 올라갈 때
	// 정적 메소드가 자동으로 생성된다. 그렇기에 인스턴스를 생성하지 않고,
	// 클래스만으로 메소드를 호출할 수 있는 것이다.
	public static UploadedFile fileUpload(String originalFilename, long size, String contentType, byte[] data,
			String realPath) {
		
		String completePath = makeCalculatePath(realPath); // 물리적경로 + /년/월/일
		
		UploadedFile uf = new UploadedFile();
		
		
		if (size > 0) {
			uf.setNewFileName(getNewFileName(originalFilename, realPath, completePath));
			
			uf.setOriginalFileName(originalFilename);
			uf.setSize(size);
			try {
				  // 스프링에서 제공하는 파일 처리 메서드
				FileCopyUtils.copy(data, new File(realPath + uf.getNewFileName()));
				
				if(ImgMimeType.contentTypeIsImage(contentType)) {
					// 스케일 다운 -> thumbnail 이름으로 파일 저장
					makeThumbNailImage(uf, realPath, completePath);
				};
			} catch (IOException e) {
				// 업로드된 원본 파일 저장 실패
				e.printStackTrace();
				uf = null;
			}
		}
		
		
		if (uf!=null) {
			System.out.println(uf.toString());
		}
		
		return uf;
	}
	
	/**
	 * @MethodName : makeThumbNailImage
	 * @author : ksh
	 * @param uf
	 * @param realPath
	 * @throws IOException 
	 * @returnValue : 
	 * @description : 이미지(원본)를 읽어와 스케일 다운 시키고, 썸네일 파일로 저장
	 * @date : 2023. 9. 1.
	 */
	private static void makeThumbNailImage(UploadedFile uf, String realPath, String completePath) throws IOException {
		BufferedImage originImg = ImageIO.read(new File(realPath + uf.getNewFileName())); // 원본파일

		BufferedImage thumbNailImg = Scalr.resize(originImg, Mode.FIT_TO_HEIGHT, 50);
		
		String thumbImgName = "thumb_" + uf.getOriginalFileName();
		
		File saveTarget = new File(completePath + File.separator + thumbImgName);
		String ext = uf.getOriginalFileName().substring(uf.getOriginalFileName().lastIndexOf(".") + 1);
		
		if (ImageIO.write(thumbNailImg, ext, saveTarget)) { // 썸네일 이미지를 저장 -> 성공이면 uf에 담기
			uf.setThumbFilename(completePath.substring(realPath.length()) + File.separator +thumbImgName);
		}
	}

	/**
	 * @MethodName : getNewFileName
	 * @author : ksh
	 * @param originalFilename
	 * @param realPath
	 * @param completePath
	 * @return
	 * @returnValue : "\년\월\일\새로운 유니크한 파일 이름.확장자" 반환
	 * @description : 
	 * @date : 2023. 9. 1.
	 */
	private static String getNewFileName(String originalFilename, String realPath, String completePath) {
		String uuid = UUID.randomUUID().toString();

		String ext = originalFilename.substring(originalFilename.lastIndexOf("."));

		String newFileName =  uuid + "_" + originalFilename;

		
		return completePath.substring(realPath.length()) + File.separator + newFileName;
	}

	/**
	 * @MethodName : makeCalculatePath
	 * @author : ksh
	 * @param realPath(저장되는 실제 경로)
	 * @return
	 * @returnValue : realPath + date (realPath + 현재 \년\월\일 폴더 경로)
	 * @description : 
	 * @date : 2023. 9. 1.
	 */
	private static String makeCalculatePath(String realPath) {
		// protected한 생성자라 상속받은 자식 클래스만 접근 가능. 
		// Calendar 객체를 반환하는 getInstance()메소드를 사용해야함.
		Calendar cal = Calendar.getInstance(); 
		// File.separator = OS마다 파일 패스에서 사용하는 파일 구분자가 다르기 때문
		String year = File.separator + cal.get(Calendar.YEAR) + ""; // "\2023"
		String month = year + File.separator + new DecimalFormat("00").format(cal.get(Calendar.MONTH) + 1); // "\2023\09"
		String date = month + File.separator + new DecimalFormat("00").format(cal.get(Calendar.DATE)); // "\2023\09\01"
		
		System.out.println(year + ", " + month + ", " + date);
		
		makeDirectory(realPath, year, month, date);
		
		return realPath + date;
	}
	
	

	// ...strings : 가변인자 메서드 기법 (전달된 year, month, date 값이 strings 하나의 매개변수로
	// 할당 된다. (배열 형식으로)
	private static void makeDirectory(String realPath, String...strings) { 
		// realPath 경로 + \년\월\일 폴더가 모두 존재하지 않는다면..
		if(!new File(realPath + strings[strings.length-1]).exists()) {
			for(String path : strings) {
				File tmp = new File(realPath + path);
				if (!tmp.exists()) {
					tmp.mkdir();
				}
			}
		}
		
	}
	
}

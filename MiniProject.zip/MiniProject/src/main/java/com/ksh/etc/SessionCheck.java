package com.ksh.etc;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener // webServer에게 SessionListner의 존재를 알림
public class SessionCheck implements HttpSessionListener {

	// Map<hostName, 유저아이디>
	
	// Map<세션아이디, 세션객체>
	private static Map<String, HttpSession> sessions = new ConcurrentHashMap<String, HttpSession>();

	/**
	 * @MethodName : duplicateLoginCheck
	 * @author : ksh
	 * @param : loginUserSessionId - 로그인한 유저의 세션값
	 * @returnValue : boolean
	 * @description : 로그인 한 세션과 동일한 세션이 있는지 검사 
	 * @date : 2023. 9. 12.
	 */
	public static synchronized void replaceSessionKey(HttpSession ses, String loginUserId) {	
		// 빈번하게 쓰이는 메서드여서 synchronized붙여줌
		
		if(!sessions.containsKey(loginUserId) && sessions.containsValue(ses)) {	// 최초 로그인할 때
			System.out.println(loginUserId + "로 최초 로그인!!!!!!!!!!!!!!!!!");
			sessions.put(loginUserId, ses); // 유저아이디값으로 키를 교체
			sessions.remove(ses.getId());	// 기존(로그인 하기 이전) 값 지우기
		} else if(sessions.containsKey(loginUserId)) {
			System.out.println(loginUserId+"로 중복 로그인 하려고 함");
			removeKey(loginUserId);	// 기존 로그인 기록 로그아웃
			sessions.put(loginUserId, ses);
		}
		
		
		printSessionsMap();
		
	}



	private static void printSessionsMap() {
		System.out.println("==============현재 생성된 세션 리스트==============");
		Set<String> keys = sessions.keySet(); // 키들의 집합
		for (String key : keys) {
			System.out.println(key + " : " + sessions.get(key).toString());
		}
		System.out.println("======================================================");
	}
	
	

	@Override
	public synchronized void sessionCreated(HttpSessionEvent se) {
		// TODO Auto-generated method stub
		System.out.println("세션이 생성됨");
		System.out.println("생성된 세션 id : " + se.getSession().getId());

		// 세션이 생성되면 Map에 해당 세션 등록
		sessions.put(se.getSession().getId(), se.getSession());

		printSessionsMap();
	}

	@Override
	public synchronized void sessionDestroyed(HttpSessionEvent se) {
		System.out.println("세션이 종료됨" + se.getSession().getId());

		// 세션이 종료 되면 Map에서도 해당 세션 삭제
		if (sessions.containsKey(se.getSession().getId())) {
			se.getSession().invalidate();
			sessions.remove(se.getSession().getId());
		}

		printSessionsMap();
	}



	public static void removeKey(String userId) {
		if(sessions.containsKey(userId)) {
			(sessions.get(userId)).removeAttribute("loginMemeber");
			if((sessions.get(userId)).getAttribute("returnPath") != null) {
				
				(sessions.get(userId)).removeAttribute("returnPath");
			}
			(sessions.get(userId)).invalidate(); // 세션 무효화
			sessions.remove(userId);	// 리스트에서 제거 
		}
		printSessionsMap();
	}

}

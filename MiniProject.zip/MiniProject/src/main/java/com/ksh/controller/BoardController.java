package com.ksh.controller;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.ksh.etc.UploadFileProcess;
import com.ksh.service.board.BoardService;
import com.ksh.vodto.Board;
import com.ksh.vodto.UploadedFile;

@Controller
@RequestMapping("/board/*")
public class BoardController {
	
	@Inject
	private BoardService bService; // BoardService 객체 주입
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	@RequestMapping("listAll")
	public void listAll(Model model) {
		
		logger.info("게시판 전체 글 조회");
		// service -> dao -> db -> service
		List<Board> lst = bService.getEntireBoard();
		
		model.addAttribute("boardList", lst); // 모델에 바인딩
	}
	
	@RequestMapping("writeBoard")
	public void showWriteBoard() {
		
	}
	
	
	/**
	 * @MethodName : uploadFile
	 * @author : ksh
	 * @param uploadFile
	 * @param req
	 * @returnValue : 
	 * @description : 
	 * @date : 2023. 9. 1.
	 */
	@RequestMapping(value="uploadFile", method = RequestMethod.POST) 
	public void uploadFile(MultipartFile uploadFile, HttpServletRequest req) {
		logger.info("파일을 업로드 했다!");
		// uploadFile.getBytes() : 바이트 배열이 나오는데 파일의 2진 데이터
		System.out.println("파일의 오리지널 이름 : " + uploadFile.getOriginalFilename());
		System.out.println("파일의 사이즈 : " + uploadFile.getSize());
		System.out.println("파일의 컨텐트 타입 : " + uploadFile.getContentType());
		
		// 파일이 저장될 물리적 경로(realPath)
		String realPath = req.getSession().getServletContext().getRealPath("resources/uploads");
		System.out.println(realPath);
		
		// 파일 처리 시작
		try { // 컨트롤러단이니 try catch 가능
			UploadedFile uf = UploadFileProcess.fileUpload(uploadFile.getOriginalFilename(), uploadFile.getSize(), uploadFile.getContentType(), 
					uploadFile.getBytes(), realPath);
			
			// 월요일 요기부터 (여러개 파일 업로드 한꺼번에 할 경우 고민해보기)
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

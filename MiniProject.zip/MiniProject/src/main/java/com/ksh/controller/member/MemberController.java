package com.ksh.controller.member;


import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ksh.service.member.MemberService;
import com.ksh.vodto.Member;
import com.ksh.vodto.MemberDTO;

@Controller
@RequestMapping("/member/*")
public class MemberController {
	
	@Inject
	private MemberService mService;
	
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@RequestMapping("login")
	public void loginGET() {
		// LoginInterceptor의 preHandle() 호출 후 
		
		// /member/login.jsp가 반환
	}
	
	@RequestMapping(value="login", method=RequestMethod.POST)
	public void loginPost(MemberDTO tmpMember, Model model) {
		logger.info(tmpMember + "로 로그인 해보자");
		try {
			Member loginMember = mService.login(tmpMember);
			if(loginMember != null) {
				logger.info("로그인 성공 : " + loginMember.toString());
				model.addAttribute("loginMember", loginMember);
			} else {
				logger.info("로그인 실패");
				return; // 서블릿단으로 다시 감
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	@RequestMapping("logout")
	public String logout(HttpServletRequest req) {
		HttpSession ses = req.getSession();
		ses.removeAttribute("loginMember");
		ses.removeAttribute("returnPath");
		ses.invalidate();
		return "redirect:/";
	}
}

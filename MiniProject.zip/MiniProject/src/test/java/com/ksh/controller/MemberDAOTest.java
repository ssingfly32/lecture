package com.ksh.controller;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ksh.persistence.MemberDAO;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( // 위치 알려주기
locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"} // ** : 폴더도 포함하고 파일도 포함		
		)
public class MemberDAOTest {
	
	@Inject
	private MemberDAO mdao;
	
	@Test
	public void testGetDate() {
		System.out.println(mdao.getDate());
	}

 }

package com.ksh.controller;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( // 위치 알려주기
locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"} // ** : 폴더도 포함하고 파일도 포함		
		)
public class SqlSessionFactoryTest {
	
	@Inject
	private SqlSessionFactory ses;
	
	@Test
	public void testFactory() {
		if (ses != null) {
			System.out.println(ses.toString());
		}
	}
}
